  <html>
    <head>
          <link type="text/css" rel="stylesheet" href="templates/face/ust.css" />
        <style>
           
           
            #fr{
                text-align: center;
            }
          
            #f{
                margin-top: 82px;
            }
           
          
          h3{
              text-align: center;
          }
            body{
              background: #d5d5d5;
            }
            #r{
                    margin-top: 132px;
            }
              
         
               </style>
    </head> 
    <body>
        
        
  
     <div style="padding: 90px 0px;background-color: #131212;">
        <h1 id="f" style="text-align: center;    color: #d6d3d3;">Customer Posts</h1>

     </div>
                   <div class="container" >
                      <div class="row">
                        <?php foreach ($file as $value) {?>
                          <div class="col-sm-6" style="margin: 40px 0px;padding-top:20px;">
                            <div style="background-color: black;">
                                 <div class="row" style="padding: 30px;">
                              <div class="col-sm-6" style="color: grey;">
                                <?php echo $value->cname;?>
                              </div>
                              <div class="col-sm-6" style="color: grey;">
                                Posted on:<?php echo $value->postdate;?>
                              </div>
                              <div class="col-sm-12">
                                <p style="color: white;margin-top: 40px;"><?php echo $value->post;?></p>

                              </div>
                            </div>
                              <div class="">
                                  <img class=" img-responsive " style="width: 100%;height: 400px;" id="p" src="<?php echo base_url();?>/uploads/<?php echo $value->pimage;?> " alt ="<?php echo $value->pimage;?>" >
                              </div>
                            </div>
                           
                          </div>
                            <?php
}




?>
                      </div>
                   </div>
                   <!--
    
        <br>
<?php foreach ($file as $value) {
  
?>
        <div class="container" style="border:1px solid #ddd;background-color: white;">     
<table class="table">
    <tr>
        <td>
        <!--<td> <img src="../uploads/<?php //echo $getf['pimage'];?> " style="width: 50px; height: 50px;" class="img-circle img-responsive " alt ="<?php //echo $getf['fimage'];?>">--
       <?php echo $value->cname;?></td><td>Posted on:<?php echo $value->postdate;?></td></tr>
    <tr><td>
           
            <p> <?php echo $value->post;?></p>
            <hr>
           <p>
             
             <img class=" img-responsive " id="p" src="<?php echo base_url();?>/uploads/<?php echo $value->pimage;?> " alt ="<?php echo $value->pimage;?>" >    </p>
<!--
     <a href="like.php?like=<?php// echo $getf['id'];?>"><span class="glyphicon glyphicon-thumbs-up"></span></a>
         <?php// echo $getf['like'];?> </td></tr>  
       
</table>
</div>
        </div>
        <br>-
             <?php
}




?>-->
    <div class="footer-cpy">
                <div class="footer-social">
                    <center>    
                <div class="cpy-right">
                    
                    <p style="text-align:center;">© 2018 All rights reserved </p>
                </div>
                    </center>
                <div class="clearfix"></div>
            </div>
           </div>
        <!-- //banner -->
</body>  
</html> 
