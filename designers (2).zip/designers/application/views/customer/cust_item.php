
<html>
	<head>
		<title>Designs
                </title>
                <link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url();?>templates/gallery/images/pageicon.png" />
                <link href="<?php echo base_url();?>templates/gallery/css/style.css" rel="stylesheet" type="text/css"  media="all" />
		<meta name="keywords" content="Videostube iphone web template, Android web template, Smartphone web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
                <link href='<?php echo base_url();?>templates/gallery///fonts.googleapis.com/css?family=Ropa+Sans' rel='stylesheet' type='text/css'>
                <style>
                    #pr{
                        font-size: 20px;
                        color: #009688;
                            
                    }
                </style>
	</head>
	<body>
        
	<!----start-wrap---->
	<div class="wrap">
		<!----start-Header---->
		<div class="header">
			<!----start-Logo---->
                        <!--
			<div class="logo">
				<a href="index.html"><img src="images/logo.png" title="logo" /></a>
			</div>-->
			<!----End-Logo---->
			<!----start-top-nav---->
			<!--<div class="top-nav">
				<ul>
					<li><a href="index.html">Home</a><p>My Frontpage</p></li>
					<li><a href="#">About</a><p>About this blog</p></li>
					<li><a href="categories.html">Categories</a><p>Be Ur Self</p></li>
					<li><a href="#">Economics</a><p>Human Needs</p></li>
					<li><a href="#">Health</a><p>Take A Trip</p></li>
					<li><a href="contact.html">Contact</a><p>Leave Messages</p></li>
				</ul>
			</div>
			<div class="clear"> </div>
			<!----End-top-nav---->
		</div>
		<!----End-Header---->
		<div class="clear"> </div>
		<div class="content">
			<div class="inner-page">
				<div class="searchbar">
					<div class="search-left">
						<p>Designs</p>
					</div>
					<div class="search-right">
						<form>
							<input type="text"><input type="submit" value="" />
						</form>
					</div>
					<div class="clear"> </div>
				</div>
				<div class="title">
                                    <?php
                                    foreach($item as $value) {
                                    ?>
					<h3><?php echo $value->dressname;?></h3>
					<ul>
                                            <!--
						<li><h4>By:</h4></li>
						<li><a href="#">Author</a></li>
						<li><a href="#"><img src="images/sub.png" title="subscribe" />subscribe</a></li>-->
					</ul>
      
				</div>
				<div class="video-inner">
					<a href="#"><img src="<?php echo base_url();?>/uploads/<?php echo $value->dress;?> " alt ="<?php echo $value->dress;?>" width='100%' height='100%'></a>
				</div>
				<div class="viwes">
					<div class="view-links">
						<!--<ul>
							<li><h4>Share on:</h4></li>
							<li><a href="#"><img src="images/f1.png" title="facebook" /></a></li>
							<li><a href="#"><img src="images/t1.png" title="Twitter" /></a></li>
							<li><a href="#"><img src="images/s1.png" title="Google+" /></a></li>
						</ul>
						<ul class="comment1">
							<li><a href="#">Comment(1)</a></li>
							<li><a href="#"><img src="images/re.png" title="report" /><span>Report</span></a></li>
						</ul>
					</div>
					<div class="views-count">
						<p><span>2,500</span> Views</p>
					</div>
					<div class="clear"> </div>-->
				</div>
				<div class="clear"> </div>
				<div class="video-details">
					<ul>
						<li><p>Uploaded on <?php echo $value->cdate;?> by <?php echo $value->dname;?></a></p></li>
                                                
						<!--<li><span>Description: <?php //echo $row['pdesc'];?></span></li>-->
					</ul>
					<ul class="other-links">
                                            <li>Description: <?php echo $value->pdesc;?></li>
                                              <li>Type: <?php echo $value->dtype;?></li>
						<li>Material: <?php echo $value->material;?></li>
						<li>Colour: <?php echo $value->colour;?></li>
                                                <li>Occasion: <?php echo $value->occation;?></li>
                                                <li><p id='pr'>Price: <?php echo $value->price;?><span id='pr'> INR</span></p></li>
						<!--<li><a href="#">Twitter.com/videos-tube</a></li>-->
					</ul>
				</div>
				<div class="clear"> </div>
				<div class="tags">
					<ul><!--
						<li><h3>Tags:</h3></li>
						<li><a href="#">Games</a> ,</li>
						<li><a href="#">HD-Videos</a></li>-->
					</ul>
				</div>
				<div class="clear"> </div>
                                                                  <?php
                                    
  }
  ?>
				
                                <!--<div class="related-videos">
					<h6>Related-Videos</h6>
				<div class="grids">
					<div class="grid">
						<h3>Consectetur adipisicing elit</h3>
						<a href="#"><img src="images/g3.jpg" title="video-name"></a>
						<div class="time">
							<span>2:30</span>
						</div>
						<div class="grid-info">
							<div class="video-share">
								<ul>
									<li><a href="#"><img src="images/likes.png" title="links"></a></li>
									<li><a href="#"><img src="images/link.png" title="Link"></a></li>
									<li><a href="#"><img src="images/views.png" title="Views"></a></li>
								</ul>
							</div>
							<div class="video-watch">
								<a href="#">Watch Now</a>
							</div>
							<div class="clear"> </div>
							<div class="lables">
								<p>Labels:<a href="#">Lorem</a></p>
							</div>
						</div>
					</div>
					<div class="grid">
						<h3>Consectetur adipisicing elit</h3>
						<a href="#"><img src="images/g5.jpg" title="video-name"></a>
						<div class="time">
							<span>5:10</span>
						</div>
						<div class="grid-info">
							<div class="video-share">
								<ul>
									<li><a href="#"><img src="images/likes.png" title="links"></a></li>
									<li><a href="#"><img src="images/link.png" title="Link"></a></li>
									<li><a href="#"><img src="images/views.png" title="Views"></a></li>
								</ul>
							</div>
							<div class="video-watch">
								<a href="#">Watch Now</a>
							</div>
							<div class="clear"> </div>
							<div class="lables">
								<p>Labels:<a href="#">Lorem</a></p>
							</div>
						</div>
					</div>
					<div class="grid">
						<h3>Consectetur adipisicing elit</h3>
						<a href="#"><img src="images/g4.jpg" title="video-name"></a>
						<div class="time">
							<span>2:00</span>
						</div>
						<div class="grid-info">
							<div class="video-share">
								<ul>
									<li><a href="#"><img src="images/likes.png" title="links"></a></li>
									<li><a href="#"><img src="images/link.png" title="Link"></a></li>
									<li><a href="#"><img src="images/views.png" title="Views"></a></li>
								</ul>
							</div>
							<div class="video-watch">
								<a href="#">Watch Now</a>
							</div>
							<div class="clear"> </div>
							<div class="lables">
								<p>Labels:<a href="#">Lorem</a></p>
							</div>
						</div>
					</div>
				</div>
				</div>
				<div class="clear"> </div>
			</div>
		<div class="right-content">
			<div class="popular">
				<h3>Popular Videos</h3>
				<p><img src="images/l1.png" title="likes" /> 10,000</p>
				<div class="clear"> </div>
			</div>
			<div class="grid1">
						<h3>Consectetur adipisicing elit</h3>
						<a href="#"><img src="images/g7.jpg" title="video-name" /></a>
						<div class="time1">
							<span>2:50</span>
						</div>
						
						<div class="grid-info">
							<div class="video-share">
								<ul>
									<li><a href="#"><img src="images/likes.png" title="links" /></a></li>
									<li><a href="#"><img src="images/link.png" title="Link" /></a></li>
									<li><a href="#"><img src="images/views.png" title="Views" /></a></li>
								</ul>
							</div>
							<div class="video-watch">
								<a href="#">Watch Now</a>
							</div>
							<div class="clear"> </div>
							<div class="lables">
								<p>Labels:<a href="#">Lorem</a></p>
							</div>
						</div>
					</div>
					<div class="clear"> </div>
		</div>
		<div class="clear"> </div>
		</div>
	</div>
		<div class="clear"> </div>
		<div class="footer">
				<div class="wrap"> 
				<div class="box1">
				<h4>Ur's Account</h4>
						<ul>
							<li><a href="#">My Channel</a></li>
							<li><a href="#">Subscription</a></li>
							<li><a href="#">Locations</a></li>
							<li><a href="#">Favourites</a></li>
							<li><a href="#">Add</a></li>
							<li><a href="#">Ur-specials</a></li>
							<li><a href="#">Submission Rules</a></li>
						</ul>
				</div>
				<div class="box1">
				<h4>Policy & Terms</h4>
						<ul>
							<li><a href="#">Terms & Conditions</a></li>
							<li><a href="#">Privacy Policy</a></li>
							<li><a href="#">Submission Rules</a></li>
							<li><a href="#">Company Buzz</a></li>
							<li><a href="#">My Staff</a></li>
							<li><a href="#">Moodle Hosting</a></li>
							<li><a href="#">OpenCart Hosting</a></li>
						</ul>
				</div>
				<div class="box1">
				<h4>Community</h4>
						<ul>
							<li><a href="#">Standard Support</a></li>
							<li><a href="#">Premier Support</a></li>
							<li><a href="#">Support Center</a></li>
							<li><a href="#">Host Affiliate</a></li>
							<li><a href="#">Infographics</a></li>
							<li><a href="#">indian Hosting</a></li>
							<li><a href="#">Green Web Hosting</a></li>
						</ul>
				</div>
				<div class="box1">
					<div class="hide-box">
				<h4>About Us</h4>
						<ul>
							<li><a href="#">Contact Us</a></li>
							<li><a href="#">Terms of Service</a></li>
							<li><a href="#">Privacy Policy</a></li>
							<li><a href="#">Blog</a></li>
							<li><a href="#">Guarantee</a></li>
							<li><a href="#">Link to Us</a></li>
							<li><a href="#">We're Hiring</a></li>
						</ul>
				</div>
					</div>
				<div class="box1">
				<h4>Stay in touch on</h4>
						<ul class="social">
							<li><img src="images/facebook.png" title="facebook"><a href="#">Facebook</a></li>
							<li><img src="images/twitter.png" title="twitter"><a href="#">Twitter</a></li>
							<li><img src="images/gplus.png" title="google+"><a href="#">Google+</a></li>
						</ul>
				</div>
				<div class="clear"> </div>
			</div>
		</div>
			<div class="clear"> </div>
			<div class="copy-right">
			<p>&#169 2013 Videostube. All Rights Reserved | Design by &nbsp;<a href="http://w3layouts.com">W3Layouts</a></p>
		</div>
	</div>
	<!----End-wrap---->
         <div class="footer-cpy">
                <div class="footer-social">
                    <center>    
                <div class="cpy-right">
                    
                    <p style="text-align:center;">© 2018 All rights reserved </p>
                </div>
                    </center>
                <div class="clearfix"></div>
            </div>
           </div>
        
	</body>
</html>

