<div class="body">
  

<div style="padding: 90px 0px;background-image: url('../images/head.jpg');
background-repeat: no-repeat;">
            <div   class="container">    
             <div  class="row">
              <div class="col-md-3"></div>
          <div class="col-md-6" style="background-color: #2b2b2bb0;
    padding: 10px 50px;">
            <div class="" style="">
              <div class="">
                <h3 class="heading">Add Details </h3>

                <p class="error">
              <?php 
              $err_msg=$this->session->flashdata('custerr');
              if($err_msg){
              echo$err_msg;
}?></p>
              </div>
<div class="">
<div class="">
                  <form action="<?php echo base_url('index.php/designerctrl/cust_posting');?>" method="post" enctype="multipart/form-data">
    <div class="form-group">
      
        <textarea class="form-controltext" id="email" placeholder="Write Something" name="text" required=""></textarea>
    </div>
   <div class="form-group col-md-6">
      <input type="file" name="file"  id="fileToUpload" required="" />
    </div>
<div class="col-md-6">
   <input type="submit" name="post" class="btnn btn-defaultt btn-block"  value="Submit" class="btn btn-default">
</div>
    
                     </form>
                      <br>
                      
                  </div>
                
</div>
        </div>
          </div></div></div>
        </div>
<div class="banner-bg-agileits">
            <!-- banner-text --
            <div class="banner-text">
                <!--counter--
                
                <div class="days-coming">
                    <div class="container">
                       <!-- <h2 class="title tittle">fashion week</h2>--
                       
                        <div class="timer_wrap">
                            <div id="counter"></div>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                </div>
                <!--//counter-->
          <!--  </div>-->
        <!--</div>-->

     <div style="padding: 80px 0px;
    background-color: black;" class="row">
    <div class="col-md-4"></div>
    <div class="col-md-4"> <h1 style="text-align: center;color: white;font-size: 3em;">Your Posts</h1>
      <hr>
  </div>
    <div class="col-md-4"></div>
      
     </div>
     <div style="background-color: #000000b5;" >
       
     
                  <div class="container" >
    
        <div class="row">

  <?php foreach ($post as $value) {
   ?> 
            <div class="col-md-6">
                <div class="polaroid">
                  <img class=" img-responsivee " id="p" src="<?php echo base_url();?>uploads/<?php echo $value->pimage;?> " alt ="<?php echo $value->pimage;?>" >
                  <div class="" style="padding: 30px 0px;">
                    <p style=""> Posted on :<?php echo $value->postdate;?></p>
                    <p style="color: white;"><?php echo $value->post;?></p>
                    <p style="text-align:right;color:;"><?php echo $value->cname;?></p>
                  </div>
                </div>
            </div>
            <?php } ?>
              
            </div>
        <!--
      
  <?php foreach ($post as $value) {
   ?>        <div class="container" style="border:1px solid #ddd;background-color: white;">     
<table class="table">
    <tr>
        <td>
        <!--<td> <img src="../uploads/<?php //echo $getf['pimage'];?> " style="width: 50px; height: 50px;" class="img-circle img-responsive " alt ="<?php //echo $getf['fimage'];?>">-->
    <!--   <?php echo $value->cname;?></td></tr>
    <tr><td>
           
            <p> <?php echo $value->post;?></p>
            <hr>
           <p>
             
             <img class=" img-responsive " id="p" src="<?php echo base_url();?>uploads/<?php echo $value->pimage;?> " alt ="<?php echo $value->pimage;?>" >    </p>
<!--
     <a href="like.php?like=<?php// echo $getf['id'];?>"><span class="glyphicon glyphicon-thumbs-up"></span></a>
         <?php// echo $getf['like'];?> </td></tr>  
 </td>
</tr>


    
       
</table>-
</div>

        <br>
        <?php 
      }
      ?>-->

    <div class="footer-cpy">
                <div class="footer-social">
                    
                <div class="cpy-right">
                    <p>© 2018 All rights reserved </p>
                </div>
                <div class="clearfix"></div>
            </div>
           </div>
</div>
</div>
</div>
        <!-- //banner -->
</body> 
 <style type="text/css">
           
           
            #fr{
                text-align: center;
            }
          
           
          
          .heading{
              text-align: center;
color: white;
text-transform: uppercase;
padding: 26px 0px;
font-size: 2.3em;
          }
            body{
              background: #d5d5d5;
            }
            #r{
                    margin-top: 132px;
            }
              
         
               </style>

</html>