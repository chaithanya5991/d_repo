
        <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Plain Page</h3>
              </div>

              <div class="title_right">
                <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                  <div class="input-group">
                 
                  </div>
                </div>
              </div>
            </div>

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Dashboard</h2>
                   
                    <div class="clearfix"></div>
                  </div>
                 
<div class="row">
  <div class="col-sm-4">
      <div class="container"
   
  <div class="row"><br>

    <div class="jumbotron" style=" border-radius:0px!important;
    box-shadow:1px 1px 4px rgba(0,0,0,0.4);
    background-size: cover;
    background-position: center center;
    background-repeat: no-repeat;
    background-color: #515356; 
    position: relative;
    height: 100%;
">
        <a href="<?php echo base_url('index.php/'.ADMIN_PATH.'designerctrl/viewdesigners/');?>" >
          <h4>Designers</h4>
          <h1><?php echo $designer;?></h1>
         </a>
        </div>
  </div>
      
  </div>
 
  <div class="col-sm-4">
      
      <div class="container"
   
  <div class="row"><br>

    <div class="jumbotron" style=" border-radius:0px!important;
    box-shadow:1px 1px 4px rgba(0,0,0,0.4);
    background-size: cover;
    background-position: center center;
    background-repeat: no-repeat;
    background-color: #515356; 
    position: relative;
    height: 100%;
">
          <a href="<?php echo base_url('index.php/'.ADMIN_PATH.'designerctrl/viewcustfeed/');?>" ><h4>Customer Message</h4>
          <h1><?php echo $cust;?></h1></a>
        </div>
  </div>
  </div>
   <div class="col-sm-4">
      
      <div class="container"
   
  <div class="row"><br>

    <div class="jumbotron" style=" border-radius:0px!important;
    box-shadow:1px 1px 4px rgba(0,0,0,0.4);
    background-size: cover;
    background-position: center center;
    background-repeat: no-repeat;
    background-color: #515356; 
    position: relative;
    height: 100%;
">
          <a href="<?php echo base_url('index.php/'.ADMIN_PATH.'designerctrl/viewdefeed/');?>" ><h4>Designer Message</h4>
          <h1><?php echo $des;?></h1></a>
        </div>
  </div>
  </div>
</div>

  </div>
</div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

        <!-- footer content -->
      