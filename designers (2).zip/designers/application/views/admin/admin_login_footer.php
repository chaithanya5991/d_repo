
                <div>
                <h1>Designer Junction</h1>
                  <p>©2018 All Rights Reserved. <a href="http://www.nyesteventuretech.com">Nyeste Venture Technologies.</a></p>
                </div>
                 </div>
            </form>
          </section>
        </div>
      </div>
    </div>
  </body>
  
</html>